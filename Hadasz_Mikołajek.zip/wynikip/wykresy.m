wyn = load('wyniki1');
plot(wyn(:, 1), wyn(:, 2));
axis([0, 100, 430, 530]);